<footer>
	<div class="container">
		<div class="row">
			<div class="col-md-2"><a href="#"><img id="logo" src="app/img/logo.svg"></a></div>
			<div class="col-md-1 lista_footer"><a href="?i=sobre">Sobre</a></div>
			<div class="col-md-1 lista_footer"><a href="?i=navegar">Navegar</a></div>
			<div class="col-md-1 lista_footer"><a href="?i=blast">Buscar</a></div>
			<div class="col-md-1 lista_footer"><a href="#">Ajuda</a></div>
		</div>
		<div class="row">
			<div class="col-md-12">
				<p>© 2017 betabase | Todos os direitos reservados. Construido por <a href="#">Diego Mariano</a>.</p>
			</div>
		</div>
	</div>
	<!-- jQuery -->
    <script src="https://code.jquery.com/jquery-3.2.1.min.js"></script>
    <script src="app/js/bootstrap.min.js"></script>
</footer>
</body>
</html>